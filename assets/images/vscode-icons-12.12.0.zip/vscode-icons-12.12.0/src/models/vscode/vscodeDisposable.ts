/* eslint-disable @typescript-eslint/no-explicit-any */

export interface IVSCodeDisposable {
  dispose(): any;
}
