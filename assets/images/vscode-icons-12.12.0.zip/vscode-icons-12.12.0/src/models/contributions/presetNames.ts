export enum PresetNames {
  angular,
  nestjs,
  jsOfficial,
  tsOfficial,
  jsonOfficial,
  hideFolders,
  foldersAllDefaultIcon,
  hideExplorerArrows,
  yamlOfficial,
}
