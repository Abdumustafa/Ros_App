export interface IIconAssociation {
  [iconName: string]: string;
}
