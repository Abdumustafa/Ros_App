import { IDefaultExtension } from './defaultExtension';

export interface IFolderDefault {
  folder?: IDefaultExtension;
  folder_light?: IDefaultExtension;
  root_folder?: IDefaultExtension;
  root_folder_light?: IDefaultExtension;
}
