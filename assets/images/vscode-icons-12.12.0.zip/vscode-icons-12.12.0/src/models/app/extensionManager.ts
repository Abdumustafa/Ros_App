export interface IExtensionManager {
  activate(): Promise<void>;
}
